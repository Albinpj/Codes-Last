# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Albin P J (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from webptools import grant_permission
from webptools import cwebp
from odoo import fields, models, api
import os
from os.path import exists
import base64


class WebsiteSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    webp_compressor = fields.Boolean(config_parameter='webp_image_optimizer.webp_compressor')

    @api.onchange('webp_compressor')
    def check_webp_compressor(self):
        if self.webp_compressor:
            for url_ids in self.env['ir.attachment'].search([('type', '=', 'url')]):
                if exists(str(os.getcwd()) + str('/addons') + str(url_ids.url)):
                    main_path = str(os.getcwd()) + str('/addons') + str(
                        os.path.abspath(os.path.join(url_ids.url, os.pardir)))

                    file_url = str(os.getcwd()) + str('/addons') + str(url_ids.url)

                    cwebp(input_image=str(os.getcwd()) + str('/addons') + str(url_ids.url),
                          output_image=str(main_path) + str('/') + str(url_ids.name.split('.')[0]) + str('.webp'),
                          option="-q 80", logging="-v")

                    file_text = open(str(os.getcwd()) + str('/addons') + str(url_ids.url), 'rb')
                    file_read = file_text.read()
                    file_encode = base64.encodebytes(file_read)

                    self.env['ir.attachment'].browse(url_ids.id).update({
                        'name': str(url_ids.name.split('.')[0]) + str('.webp'),
                        'datas': file_encode,
                        'mimetype': 'image/' + str('webp'),
                        'url': str(url_ids.url.split('.')[0]) + str('.webp'),
                    })
                    os.remove(file_url)

        grant_permission()

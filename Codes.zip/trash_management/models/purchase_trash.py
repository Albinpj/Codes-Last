# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Albin P J (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import fields, models, api


class DeletePurchase(models.Model):
    _inherit = 'purchase.order'
    _description = "Purchase Trash Management"

    def unlink(self):
        for rec in self:
            purchase_trash_id = self.env['purchase.trash'].create({
                'vendor_id': rec.partner_id.id,
                'name': rec.name,
                'partner_ref': rec.partner_ref,
                'currency_id': rec.currency_id.id,
                'company_id': rec.company_id.id,
                'user_id': rec.user_id.id,
                'date_order': rec.date_order,
                'expected_arrival': rec.date_planned,
                'origin': rec.origin,
                'state': rec.state,
                'payment_term_id': rec.payment_term_id.id,
                'fiscal_position_id': rec.fiscal_position_id.id,
                'incoterm_id': rec.incoterm_id.id,
                'incoterm_location': rec.incoterm_location,
                'l10n_in_journal_id': rec.l10n_in_journal_id.id

            })

            for rec_order_line in rec.order_line:
                purchase_trash_id.write({
                    'purchase_order_ids': [(0, 0, {
                        'product_id': rec_order_line.product_id.id,
                        'description': rec_order_line.name,
                        'quantity': rec_order_line.product_qty,
                        'received': rec_order_line.qty_received,
                        'invoiced': rec_order_line.qty_invoiced,
                        'unit_price': rec_order_line.price_unit,
                        'taxes_ids': rec_order_line.taxes_id,
                        'sub_total': rec_order_line.price_subtotal,
                    })]
                })
        return super(DeletePurchase, self).unlink()


class PurchaseTrash(models.Model):
    _name = "purchase.trash"
    _description = "Purchase Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Reference", readonly=True)
    vendor_id = fields.Many2one('res.partner', string="Vendor", readonly=True)
    gst_treatment = fields.Many2one('account.journal', string="GST Treatment", readonly=True)
    partner_ref = fields.Char('Vendor Reference', readonly=True)
    currency_id = fields.Many2one('res.currency', 'Currency', readonly=True)
    company_id = fields.Many2one('res.company', string="Company", readonly=True)
    user_id = fields.Many2one('res.users', string="Buyer", readonly=True)
    date_order = fields.Datetime(string="Order Deadline", readonly=True)
    expected_arrival = fields.Datetime(string="Expected Arrival", readonly=True)
    origin = fields.Char(string="Source Document", readonly=True)
    state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent', 'RFQ Sent'),
        ('purchase', 'Purchase Order'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)
    payment_term_id = fields.Many2one('account.payment.term', 'Payment Terms', readonly=True)
    fiscal_position_id = fields.Many2one('account.fiscal.position', string='Fiscal Position', readonly=True)
    incoterm_id = fields.Many2one('account.incoterms', 'Incoterm', readonly=True)
    incoterm_location = fields.Char(string='Incoterm Location')
    l10n_in_journal_id = fields.Many2one('account.journal', string="Journal")
    purchase_order_ids = fields.One2many('purchase.trash.order.line', 'purchase_order_id', string="Products Order Line",
                                         readonly=True)

    @api.model
    def delete_purchase_trash(self):
        document = self.env['purchase.trash'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.purchase_clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_purchase_order(self):
        for rec in self:
            purchase_order_id = self.env['purchase.order'].create({
                'partner_id': rec.vendor_id.id,
                'name': rec.name,
                'partner_ref': rec.partner_ref,
                'currency_id': rec.currency_id.id,
                'company_id': rec.company_id.id,
                'user_id': rec.user_id.id,
                'date_order': rec.date_order,
                'date_planned': rec.expected_arrival,
                'origin': rec.origin,
                'state': rec.state,
                'payment_term_id': rec.payment_term_id.id,
                'fiscal_position_id': rec.fiscal_position_id.id,
                'incoterm_id': rec.incoterm_id.id,
                'incoterm_location': rec.incoterm_location,
                'l10n_in_journal_id': rec.l10n_in_journal_id.id

            })
        for rec_order_line in self.purchase_order_ids:
            purchase_order_id.write({
                'order_line': [(0, 0, {
                    'product_id': rec_order_line.product_id.id,
                    'name': rec_order_line.description,
                    'product_qty': rec_order_line.quantity,
                    'qty_received': rec_order_line.received,
                    'qty_invoiced': rec_order_line.invoiced,
                    'price_unit': rec_order_line.unit_price,
                    'taxes_id': rec_order_line.taxes_ids,
                })]
            })
        rec.unlink()


class PurchaseOrderLine(models.Model):
    _name = "purchase.trash.order.line"

    purchase_order_id = fields.Many2one('purchase.trash')
    product_id = fields.Many2one('product.product', string="Product")
    description = fields.Char(string="Description")
    quantity = fields.Float(string="Quantity")
    received = fields.Float(string="Received")
    invoiced = fields.Float(string="Invoiced")
    unit_price = fields.Float(string="Unit Price")
    taxes_ids = fields.Many2many('account.tax', string="Taxes")
    sub_total = fields.Float(string="Sub Total")


class PurchaseTrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    purchase_clear_trash = fields.Integer(config_parameter='trash_management.purchase_clear_trash')

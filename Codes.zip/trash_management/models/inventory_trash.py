# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Albin P J (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import fields, models, api


class DeleteInventory(models.Model):
    _inherit = 'stock.picking'
    _description = "Stock Trash Management"

    def unlink(self):
        for rec in self:
            stock_trash_id = self.env['inventory.trash'].create({
                'partner_id': rec.partner_id.id,
                'name': rec.name,
                'picking_type_id': rec.picking_type_id.id,
                'location_id': rec.location_id.id,
                'location_dest_id': rec.location_dest_id.id,
                'scheduled_date': rec.scheduled_date,
                'products_availability': rec.products_availability,
                'origin': rec.origin,
                'state': rec.state,
                'move_type': rec.move_type,
                'user_id': rec.user_id.id,
                'group_id': rec.group_id.id,
                'company_id': rec.company_id.id,

            })

            for rec_order_line in rec.move_ids_without_package:
                stock_trash_id.write({
                    'inventory_ids': [(0, 0, {
                        'product_id': rec_order_line.product_id.id,
                        'name': rec_order_line.name,
                        'date': rec_order_line.date,
                        'date_deadline': rec_order_line.date_deadline,
                        'product_packaging_id': rec_order_line.product_packaging_id.id,
                        'product_uom_qty': rec_order_line.product_uom_qty,
                        'product_uom': rec_order_line.product_uom.id,
                        'lot_ids': rec_order_line.lot_ids,
                        'location_id': rec_order_line.location_id.id,
                        'location_dest_id': rec_order_line.location_dest_id.id
                    })]
                })
        return super(DeleteInventory, self).unlink()


class InventoryTrash(models.Model):
    _name = "inventory.trash"
    _description = "Inventory Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    partner_id = fields.Many2one('res.partner', string='Contact', readonly=True)
    name = fields.Char(string="Reference", readonly=True)
    picking_type_id = fields.Many2one('stock.picking.type', string='Operation Type', readonly=True)
    location_id = fields.Many2one('stock.location', string="Source Location", readonly=True)
    location_dest_id = fields.Many2one('stock.location', string="Destination Location", readonly=True)
    scheduled_date = fields.Datetime(string='Scheduled Date', readonly=True)
    products_availability = fields.Char(string="Product Availability", readonly=True)
    origin = fields.Char(string='Source Document', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('waiting', 'Waiting Another Operation'),
        ('confirmed', 'Waiting'),
        ('assigned', 'Ready'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True)
    move_type = fields.Selection([
        ('direct', 'As soon as possible'), ('one', 'When all products are ready')], string='Shipping Policy',
        readonly=True)
    user_id = fields.Many2one('res.users', string='Responsible', readonly=True)
    group_id = fields.Many2one('procurement.group', string='Procurement Group', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    inventory_ids = fields.One2many('inventory.trash.order.line', 'inventory_id', string="Inventory Order Line",
                                    readonly=True)

    @api.model
    def delete_inventory_trash(self):
        document = self.env['inventory.trash'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.transfers_clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_inventory(self):
        for rec in self:
            stock_order_id = self.env['stock.picking'].create({
                'partner_id': rec.partner_id.id,
                'name': rec.name,
                'picking_type_id': rec.picking_type_id.id,
                'location_id': rec.location_id.id,
                'location_dest_id': rec.location_dest_id.id,
                'scheduled_date': rec.scheduled_date,
                'products_availability': rec.products_availability,
                'origin': rec.origin,
                'state': rec.state,
                'move_type': rec.move_type,
                'user_id': rec.user_id.id,
                'group_id': rec.group_id.id,
                'company_id': rec.company_id.id,

            })

        for inventory_order_line in self.inventory_ids:
            stock_order_id.write({
                'move_ids_without_package': [(0, 0, {
                    'product_id': inventory_order_line.product_id.id,
                    'name': inventory_order_line.name,
                    'description_picking': inventory_order_line.name,
                    'date': inventory_order_line.date,
                    'date_deadline': inventory_order_line.date_deadline,
                    'product_packaging_id': inventory_order_line.product_packaging_id.id,
                    'product_uom_qty': inventory_order_line.product_uom_qty,
                    'product_uom': inventory_order_line.product_uom.id,
                    'lot_ids': inventory_order_line.lot_ids,
                    'location_id': rec.location_id.id,
                    'location_dest_id': rec.location_dest_id.id
                })]
            })
        rec.unlink()


class InventoryOrderLine(models.Model):
    _name = "inventory.trash.order.line"

    product_id = fields.Many2one(
        'product.product', string='Product')
    name = fields.Char('Description', required=True)
    date = fields.Datetime(string='Date Scheduled', readonly=True)
    date_deadline = fields.Datetime(string="Deadline")
    product_packaging_id = fields.Many2one('product.packaging', string='Packaging')
    product_uom_qty = fields.Float(string='Demand')
    product_uom = fields.Many2one('uom.uom', string="UoM")
    lot_ids = fields.Many2many('stock.lot', string='Serial Numbers')
    location_id = fields.Many2one('stock.location', string="Source Location", readonly=True)
    location_dest_id = fields.Many2one('stock.location', string="Destination Location", readonly=True)
    inventory_id = fields.Many2one('inventory.trash')


class InventoryTrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    transfers_clear_trash = fields.Integer(config_parameter='trash_management.transfers_clear_trash')

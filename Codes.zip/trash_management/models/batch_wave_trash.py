# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Albin P J (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import fields, models, api


class DeleteBatchWave(models.Model):
    _inherit = 'stock.picking.batch'
    _description = "Batch Wave Trash Management"

    def unlink(self):
        for rec in self:
            print(rec.is_wave)
            batch_wave_trash_id = self.env['batch.wave.trash'].create({
                'user_id': rec.user_id.id,
                'name': rec.name,
                'picking_type_id': rec.picking_type_id.id,
                'company_id': rec.company_id.id,
                'scheduled_date': rec.scheduled_date,
                'state': rec.state,
                'is_wave': rec.is_wave
            })

            for rec_order_line in rec.picking_ids:
                batch_wave_trash_id.write({
                    'batch_wave_ids': [(0, 0, {
                        'scheduled_date': rec_order_line.scheduled_date,
                        'name': rec_order_line.name,
                        'location_id': rec_order_line.location_id.id,
                        'location_dest_id': rec_order_line.location_dest_id.id,
                        'backorder_id': rec_order_line.backorder_id.id,
                        'origin': rec_order_line.origin,
                        'state': rec_order_line.state,
                    })]
                })

        return super(DeleteBatchWave, self).unlink()


class BatchWaveTrash(models.Model):
    _name = "batch.wave.trash"
    _description = "Batch Wave Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Batch Transfer', readonly=True)
    user_id = fields.Many2one('res.users', string='Responsible', readonly=True)
    picking_type_id = fields.Many2one('stock.picking.type', string='Operation Type', readonly=True)
    company_id = fields.Many2one('res.company', string="Company", readonly=True)
    scheduled_date = fields.Datetime(string='Scheduled Date', readonly=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In progress'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')], string='State', readonly=True)
    is_wave = fields.Boolean('This batch is a wave')
    batch_wave_ids = fields.One2many('batch.wave.trash.order.line', 'batch_wave_id', string="Batch Wave Order Line",
                                     readonly=True)

    @api.model
    def delete_batch_wave_trash(self):
        document = self.env['batch.wave.trash'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.batch_wave_clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_batch_wave(self):
        if self.is_wave:
            for rec in self:
                batch_wave_order_id = self.env['stock.picking.batch'].create({
                    'is_wave': True,
                    'user_id': rec.user_id.id,
                    'name': rec.name,
                    'picking_type_id': rec.picking_type_id.id,
                    'company_id': rec.company_id.id,
                    'scheduled_date': rec.scheduled_date,
                    'state': rec.state,

                })
            picking_ids = []
            for transfer_order_line in self.batch_wave_ids:
                stock_id = self.env['stock.picking'].search([('name', '=', transfer_order_line.name)])
                picking_ids.append(stock_id.id)
                batch_wave_order_id.picking_ids = picking_ids

            rec.unlink()

        else:
            for rec in self:
                batch_wave_order_id = self.env['stock.picking.batch'].create({
                    'is_wave': False,
                    'user_id': rec.user_id.id,
                    'name': rec.name,
                    'picking_type_id': rec.picking_type_id.id,
                    'company_id': rec.company_id.id,
                    'scheduled_date': rec.scheduled_date,
                    'state': rec.state,

                })
            picking_ids = []
            for transfer_order_line in self.batch_wave_ids:
                stock_id = self.env['stock.picking'].search([('name', '=', transfer_order_line.name)])
                picking_ids.append(stock_id.id)
                batch_wave_order_id.picking_ids = picking_ids

            rec.unlink()


class BatchWaveOrderLine(models.Model):
    _name = "batch.wave.trash.order.line"

    name = fields.Char(string="Reference")
    scheduled_date = fields.Datetime(string='Scheduled Date')
    location_id = fields.Many2one('stock.location', string="Source Location")
    location_dest_id = fields.Many2one('stock.location', string="Destination Location")
    picking_type_id = fields.Many2one('stock.picking.type', string='Operation Type', readonly=True)
    backorder_id = fields.Many2one('stock.picking', string='Back Order of')
    origin = fields.Char(string='Source Document')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('waiting', 'Waiting Another Operation'),
        ('confirmed', 'Waiting'),
        ('assigned', 'Ready'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status')
    batch_wave_id = fields.Many2one('batch.wave.trash')


class InventoryBatchWaveTrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    batch_wave_clear_trash = fields.Integer(config_parameter='trash_management.batch_wave_clear_trash')

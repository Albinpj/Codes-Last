# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Albin P J (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from odoo import fields, models, api


class DeleteInvoice(models.Model):
    _inherit = 'account.move'
    _description = "Purchase Trash Management"

    def unlink(self):
        for rec in self:
            invoice_trash_id = self.env['invoice.trash'].create({
                'partner_id': rec.partner_id.id,
                'name': rec.name,
                'l10n_in_gst_treatment': rec.l10n_in_gst_treatment,
                'invoice_date': rec.invoice_date,
                'payment_reference': rec.payment_reference,
                'invoice_payment_term_id': rec.invoice_payment_term_id.id,
                'ref': rec.ref,
                'invoice_user_id': rec.invoice_user_id.id,
                'team_id': rec.team_id.id,
                'partner_bank_id': rec.partner_bank_id.id,
                'company_id': rec.company_id.id,
                'invoice_incoterm_id': rec.invoice_incoterm_id.id,
                'fiscal_position_id': rec.fiscal_position_id.id,
                'auto_post': rec.auto_post,
                'to_check': rec.to_check,
                'state': rec.state,
                'move_type': rec.move_type,
                'date': rec.date,
                'invoice_date_due': rec.invoice_date_due

            })

            for rec_order_line in rec.invoice_line_ids:
                invoice_trash_id.write({
                    'invoice_ids': [(0, 0, {
                        'product_id': rec_order_line.product_id.id,
                        'name': rec_order_line.name,
                        'quantity': rec_order_line.quantity,
                        'price_unit': rec_order_line.price_unit,
                        'tax_ids': rec_order_line.tax_ids,
                        'price_subtotal': rec_order_line.price_subtotal,
                    })]
                })
        return super(DeleteInvoice, self).unlink()


class InvoiceTrash(models.Model):
    _name = "invoice.trash"
    _description = "Invoice Trash"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Reference", readonly=True)
    partner_id = fields.Many2one('res.partner', string="Customer", readonly=True)
    l10n_in_gst_treatment = fields.Selection([
        ('regular', 'Registered Business - Regular'),
        ('composition', 'Registered Business - Composition'),
        ('unregistered', 'Unregistered Business'),
        ('consumer', 'Consumer'),
        ('overseas', 'Overseas'),
        ('special_economic_zone', 'Special Economic Zone'),
        ('deemed_export', 'Deemed Export'),
        ('uin_holders', 'UIN Holders'),
    ], string="GST Treatment", readonly=True)
    invoice_date = fields.Date(string='Invoice/Bill Date', readonly=True)
    date = fields.Date(string='Accounting Date', readonly=True)
    invoice_date_due = fields.Date(string='Date Due', readonly=True)
    payment_reference = fields.Char(string='Payment Reference', readonly=True)
    invoice_payment_term_id = fields.Many2one('account.payment.term', string='Payment Terms', readonly=True)
    ref = fields.Char(string='Customer Reference', readonly=True)
    invoice_user_id = fields.Many2one('res.users', string='Salesperson', readonly=True)
    team_id = fields.Many2one('crm.team', string="Sales Team", readonly=True)
    partner_bank_id = fields.Many2one('res.partner.bank', string='Recipient Bank', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    invoice_incoterm_id = fields.Many2one('account.incoterms', string='Incoterm', readonly=True)
    fiscal_position_id = fields.Many2one('account.fiscal.position', string='Fiscal Position', readonly=True)
    auto_post = fields.Selection(
        selection=[
            ('no', 'No'),
            ('at_date', 'At Date'),
            ('monthly', 'Monthly'),
            ('quarterly', 'Quarterly'),
            ('yearly', 'Yearly'),
        ], string='Auto-post', readonly=True)
    move_type = fields.Selection(
        selection=[
            ('entry', 'Journal Entry'),
            ('out_invoice', 'Customer Invoice'),
            ('out_refund', 'Customer Credit Note'),
            ('in_invoice', 'Vendor Bill'),
            ('in_refund', 'Vendor Credit Note'),
            ('out_receipt', 'Sales Receipt'),
            ('in_receipt', 'Purchase Receipt'),
        ],
        string='Move Type')
    to_check = fields.Boolean(string='To Check', readonly=True)
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('posted', 'Posted'),
            ('cancel', 'Cancelled'),
        ], string='State', readonly=True)
    invoice_ids = fields.One2many('invoice.trash.order.line', 'invoice_id', string="Invoice Lines",
                                  readonly=True)

    @api.model
    def delete_invoice_trash(self):
        document = self.env['invoice.trash'].search([])
        limit = self.env['ir.config_parameter'].sudo().get_param('trash_management.invoice_clear_trash')
        for doc in document:
            if doc.create_date:
                delta = fields.Datetime.today() - doc.create_date
                if delta.days >= int(limit):
                    doc.unlink()

    def action_restore_invoice(self):
        if self.move_type == 'in_invoice':
            for rec in self:
                invoice_trash_id = self.env['account.move'].create({
                    'move_type': 'in_invoice',
                    'partner_id': rec.partner_id.id,
                    'name': rec.name,
                    'l10n_in_gst_treatment': rec.l10n_in_gst_treatment,
                    'invoice_date': rec.invoice_date,
                    'payment_reference': rec.payment_reference,
                    'invoice_payment_term_id': rec.invoice_payment_term_id.id,
                    'ref': rec.ref,
                    'invoice_user_id': rec.invoice_user_id.id,
                    'team_id': rec.team_id.id,
                    'partner_bank_id': rec.partner_bank_id.id,
                    'company_id': rec.company_id.id,
                    'invoice_incoterm_id': rec.invoice_incoterm_id.id,
                    'fiscal_position_id': rec.fiscal_position_id.id,
                    'auto_post': rec.auto_post,
                    'to_check': rec.to_check,
                    'state': rec.state,
                    'date': rec.date,
                    'invoice_date_due': rec.invoice_date_due

                })

            for invoice_order_line in self.invoice_ids:
                invoice_trash_id.write({
                    'invoice_line_ids': [(0, 0, {
                        'product_id': invoice_order_line.product_id.id,
                        'name': invoice_order_line.name,
                        'quantity': invoice_order_line.quantity,
                        'price_unit': invoice_order_line.price_unit,
                        'tax_ids': invoice_order_line.tax_ids,
                        'price_subtotal': invoice_order_line.price_subtotal,
                    })]
                })

            rec.unlink()

        elif self.move_type == 'out_invoice':
            for rec in self:
                invoice_trash_id = self.env['account.move'].create({
                    'move_type': 'out_invoice',
                    'partner_id': rec.partner_id.id,
                    'name': rec.name,
                    'l10n_in_gst_treatment': rec.l10n_in_gst_treatment,
                    'invoice_date': rec.invoice_date,
                    'payment_reference': rec.payment_reference,
                    'invoice_payment_term_id': rec.invoice_payment_term_id.id,
                    'ref': rec.ref,
                    'invoice_user_id': rec.invoice_user_id.id,
                    'team_id': rec.team_id.id,
                    'partner_bank_id': rec.partner_bank_id.id,
                    'company_id': rec.company_id.id,
                    'invoice_incoterm_id': rec.invoice_incoterm_id.id,
                    'fiscal_position_id': rec.fiscal_position_id.id,
                    'auto_post': rec.auto_post,
                    'to_check': rec.to_check,
                    'state': rec.state,

                })

            for invoice_order_line in self.invoice_ids:
                invoice_trash_id.write({
                    'invoice_line_ids': [(0, 0, {
                        'product_id': invoice_order_line.product_id.id,
                        'name': invoice_order_line.name,
                        'quantity': invoice_order_line.quantity,
                        'price_unit': invoice_order_line.price_unit,
                        'tax_ids': invoice_order_line.tax_ids,
                        'price_subtotal': invoice_order_line.price_subtotal,
                    })]
                })
            rec.unlink()


class InvoiceOrderLine(models.Model):
    _name = "invoice.trash.order.line"

    product_id = fields.Many2one('product.product', string='Product')
    name = fields.Char(string='Label')
    quantity = fields.Float(string='Quantity')
    price_unit = fields.Float(string='Unit Price')
    tax_ids = fields.Many2many('account.tax', string="Taxes")
    price_subtotal = fields.Float(string='Subtotal')
    invoice_id = fields.Many2one('invoice.trash', string='Invoice')


class InvoiceTrashSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    invoice_clear_trash = fields.Integer(config_parameter='trash_management.purchase_clear_trash')

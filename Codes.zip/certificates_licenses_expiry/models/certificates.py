# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<https://www.cybrosys.com>).
#    Author: Albin P J (odoo@cybrosys.com)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU AFFERO GENERAL PUBLIC LICENSE (AGPL v3) for more details.
#
#    You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
#    (AGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
from random import randint

from datetime import date

from odoo import api, fields, models
from odoo.addons.portal.controllers import portal

from odoo.http import request


class Certificates(models.Model):
    _name = 'certificates'
    _description = "Certificates"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    state = fields.Selection(
        selection=[('new', 'New'), ('active', 'Active'), ('expired_soon', 'Expired Soon'), ('expired', 'Expired')],
        string="State", default='new')
    name = fields.Char(string='Name', required=True)
    certificate_number = fields.Char(string="Certificate Number", readonly=True, required=True, copy=False,
                                     default='New')
    customer_id = fields.Many2one('res.partner', string="Customer", required=True)
    certificates_types_id = fields.Many2one('certificates.types', string="Certificates Types", required=True)
    start_date = fields.Date(string="Start Date", required=True)
    expire_date = fields.Date(string="Expire Date", required=True)
    issued_by_id = fields.Many2one('res.company', string="Issued By", required=True)
    certificates_tags = fields.Many2many('certificates.tags', string="Tags")
    project_id = fields.Many2one('project.project', string="Project", required=True)
    task_id = fields.Many2one('project.task', string="Task", domain="[('project_id', '=', project_id)]", required=True)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    user_id = fields.Many2one('res.users', string="Responsible User", required=True)
    company_id = fields.Many2one('res.company', string="Company", required=True)
    expire_remainder_day = fields.Integer(string="Expire Remainder Day")
    login_user_id = fields.Many2one('res.users', string='Login User', default=lambda self: self.env.user, readonly=True)
    internal_notes = fields.Text(string="Internal Notes")
    description = fields.Text(string="Description")
    achievements = fields.Text(string="Achievements")

    @api.model
    def create(self, vals):
        if vals.get('certificate_number', 'New') == 'New':
            vals['certificate_number'] = self.env['ir.sequence'].next_by_code('certificates') or 'New'
        result = super(Certificates, self).create(vals)
        return result

    def active_certificate(self):
        self.state = 'active'

    def action_active_certificate(self):
        return {
            'name': 'Active',
            'view_mode': 'tree',
            'res_model': 'certificates',
            'type': 'ir.actions.act_window',
            'domain': [('state', '=', 'active')],
            'context': "{'create': False}"
        }

    def certificate_expiry_action(self):
        certificates = self.env['certificates'].search([])
        for rec in certificates:
            if date.today() >= rec.expire_date:
                rec.state = 'expired'

            if fields.Date.today() == fields.Date.subtract(rec.expire_date, days=rec.expire_remainder_day):
                rec.state = 'expired_soon'
            today = date.today()
            if today >= rec.expire_date:
                email_values = {
                    'email_cc': False,
                    'auto_delete': True,
                    'recipient_ids': [],
                    'partner_ids': [],
                    'scheduled_date': False,
                    'email_to': rec.customer_id.email
                }
                print(email_values)
                template = self.env.ref('certificates_licenses_expiry.email_template_certificate')
                template.send_mail(rec.id, force_send=True, email_values=email_values)

    def action_create_certificate_pdf_report(self):
        data = {
            'record1': self.name,
            'record2': self.certificate_number,
            'record3': self.customer_id.name,
            'record4': self.certificates_types_id.certificate_type,
            'record5': self.start_date,
            'record6': self.expire_date,
            'record7': self.issued_by_id.name,
            'record8': self.project_id.name,
            'record9': self.task_id.name,
            'record10': self.user_id.name,
            'record11': self.company_id.name,
            'record12': self.internal_notes,
            'record13': self.description,
            'record14': self.achievements,
            'record15': self.expire_remainder_day,
            'record16': self.product_id.name,
            'record17': self.state
        }
        return self.env.ref('certificates_licenses_expiry.action_certificate_report').report_action(None, data=data)


class Return(portal.CustomerPortal):
    def _prepare_home_portal_values(self, counters):
        # print("counters", counters)
        values = super(Return, self)._prepare_home_portal_values(counters)
        certificates = request.env['certificates'].search([])
        count = len(certificates)
        values.update({
            'certificates': count
        })
        # print(values, "values")
        return values

#
# class MyCertificates(http.Controller):
#     @http.route(['/my/certificates'], type='http', auth="user", website=True)
#     def get_my_certificates(self):
#         print("sdfghj")
#         certificates = request.env['certificates'].sudo().search([])
#         print(certificates)
#         # event_slot = upcoming_events.event_slot_ids
#         # print("event_slot", event_slot)
#         values = {'my_certificates': certificates,
#                   }
#
#         return request.render("certificates_licenses_expiry.portal_my_certificates", values)
#
#     @http.route(['/my/certificates/form/<int:cer_id>'], type='http', auth="user", website=True)
#     def get_my_certificates_form(self, cer_id):
#         print(cer_id)
#         certificates = request.env['certificates'].sudo().search([('id', '=', cer_id)])
#         print(certificates)
#         values = {
#             'my_certificates': certificates,
#         }
#         return request.render("certificates_licenses_expiry.certificates_portal_form_template", values)
#

class CertificatesType(models.Model):
    _name = 'certificates.types'
    _description = "Certificates Type"
    _rec_name = 'certificate_type'

    certificate_type = fields.Char(string="Certificate Type", required=True)


class CertificateTags(models.Model):
    _name = 'certificates.tags'
    _description = "Certificate Tag"
    _rec_name = 'certificates_tags'

    def _get_default_color(self):
        return randint(1, 11)

    certificates_tags = fields.Char(string="Certificate Tag", required=True)
    color = fields.Integer(string="Color", default=_get_default_color)
